import paramiko
from scp import SCPClient
from datetime import datetime

ssh = paramiko.client.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
key = paramiko.RSAKey.from_private_key_file('python.pem')

ssh.connect('54.173.165.229', username='ubuntu', pkey=key)

with SCPClient(ssh.get_transport()) as scp:
    scp.put('app.tar.gz')

tag = datetime.now().strftime('%Y%m%d%H%M%S')

print('extraindo pacote...app.tar.gz')
stdin, stdout, stderr = ssh.exec_command('sudo tar -xzf app.tar.gz')
print(stdout.read().decode('utf-8'))
print('docker build...')
stdin, stdout, stderr = ssh.exec_command('sudo docker build -t app:{0} .'.format(tag))
print(stdout.read().decode('utf-8'))
print('docker clean...')
stdin, stdout, stderr = ssh.exec_command('sudo docker rm -f $(sudo docker ps -qa)')
print(stdout.read().decode('utf-8'))
print('docker run...')
stdin, stdout, stderr = ssh.exec_command('sudo docker run -dti -p 80:80 --name app app:{0}'.format(tag))
print(stdout.read().decode('utf-8'))