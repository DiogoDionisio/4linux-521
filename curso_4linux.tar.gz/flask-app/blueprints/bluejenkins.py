import jenkins
from config import jk
from flask import Blueprint, render_template, flash, redirect, request

jhost= 'http://{0}:{1}'.format(jk['host'], jk['port'])
jserver = jenkins.Jenkins(jhost, username=jk['user'], password=jk['pass'])

bluejenkins = Blueprint('Bluejenkins', __name__)

@bluejenkins.route('/jenkins')
def get_jenkins():
	jobs = jserver.get_jobs()
	print(jobs)
	return render_template('jenkins.html', jobs=jobs)

@bluejenkins.route('/jenkins/build/<job>')
def build_jenkins(job):
	for j in jserver.get_jobs():
		if j['name'] == job:
			jserver.build_job(job)
			flash('Job {0} não foi iniciado com sucesso!'.format(job), 'success')
			break
	else:
		flash('Job {0} não encontrado porra.'.format(job), 'danger')
	return redirect('/jenkins')